PATH=D:\git-sdk-arm64\usr\src\MINGW-packages\mingw-w64-git\pkg\mingw-w64-clang-aarch64-git-test-artifacts\clangarm64\bin;C:\WINDOWS;C:\WINDOWS\system32
@set GIT_TEST_INSTALLED=D:/git-sdk-arm64/usr/src/MINGW-packages/mingw-w64-git/pkg/mingw-w64-clang-aarch64-git-test-artifacts/clangarm64/bin
@D:
@cd \git-sdk-arm64\usr\src\MINGW-packages\mingw-w64-git\pkg\mingw-w64-clang-aarch64-git-test-artifacts\test-git\t
@echo Now, run 'helper\test-run-command testsuite'
