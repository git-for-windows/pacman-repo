PATH=C:\git-sdk-arm64-build-installers\usr\src\MINGW-packages\mingw-w64-git\pkg\mingw-w64-clang-aarch64-git-test-artifacts\clangarm64\bin;C:\WINDOWS;C:\WINDOWS\system32
@set GIT_TEST_INSTALLED=C:/git-sdk-arm64-build-installers/usr/src/MINGW-packages/mingw-w64-git/pkg/mingw-w64-clang-aarch64-git-test-artifacts/clangarm64/bin
@C:
@cd \git-sdk-arm64-build-installers\usr\src\MINGW-packages\mingw-w64-git\pkg\mingw-w64-clang-aarch64-git-test-artifacts\test-git\t
@echo Now, run 'helper\test-run-command testsuite'
