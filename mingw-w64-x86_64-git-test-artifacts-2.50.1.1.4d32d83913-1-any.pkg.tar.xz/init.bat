PATH=D:\git-sdk-64\usr\src\MINGW-packages\mingw-w64-git\pkg\mingw-w64-x86_64-git-test-artifacts\mingw64\bin;C:\WINDOWS;C:\WINDOWS\system32
@set GIT_TEST_INSTALLED=D:/git-sdk-64/usr/src/MINGW-packages/mingw-w64-git/pkg/mingw-w64-x86_64-git-test-artifacts/mingw64/bin
@D:
@cd \git-sdk-64\usr\src\MINGW-packages\mingw-w64-git\pkg\mingw-w64-x86_64-git-test-artifacts\test-git\t
@echo Now, run 'helper\test-run-command testsuite'
