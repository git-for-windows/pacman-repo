PATH=D:\git-sdk-32\usr\src\MINGW-packages\mingw-w64-git\pkg\mingw-w64-i686-git-test-artifacts\mingw32\bin;C:\WINDOWS;C:\WINDOWS\system32
@set GIT_TEST_INSTALLED=D:/git-sdk-32/usr/src/MINGW-packages/mingw-w64-git/pkg/mingw-w64-i686-git-test-artifacts/mingw32/bin
@D:
@cd \git-sdk-32\usr\src\MINGW-packages\mingw-w64-git\pkg\mingw-w64-i686-git-test-artifacts\test-git\t
@echo Now, run 'helper\test-run-command testsuite'
