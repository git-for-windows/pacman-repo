perl -S ccc-analyzer %*
