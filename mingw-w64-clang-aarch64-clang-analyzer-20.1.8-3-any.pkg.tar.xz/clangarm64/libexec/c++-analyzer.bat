perl -S c++-analyzer %*
